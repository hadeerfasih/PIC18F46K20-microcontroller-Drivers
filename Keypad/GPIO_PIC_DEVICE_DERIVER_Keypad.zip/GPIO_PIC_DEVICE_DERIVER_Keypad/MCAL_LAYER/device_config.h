/* 
 * File:   device_config.h
 * Author: Hadeer.Shrif
 *
 * Created on March 29, 2024, 5:59 PM
 */

#ifndef DEVICE_CONFIG_H
#define	DEVICE_CONFIG_H

/////////section : Macro declarations ////////////////////

/////////section : Macro function declarations ///////////

/////////section : Data type declarations ///////////////

/////////section : Function declarations ///////////////


#endif	/* DEVICE_CONFIG_H */

