/* 
 * File:   ecu_keypad.h
 * Author: Hadeer Shrif
 *
 * Created on August 28, 2024, 8:34 PM
 */

#ifndef ECU_KEYPAD_H
#define	ECU_KEYPAD_H

/*section : includes*/
#include "ecu_keypad_config.h"
/*section : Macro declarations*/
#define ECU_KEYPAD_ROWS    4
#define ECU_KEYPAD_COLUMNS 4
/*section : Macro function declarations*/

/*section : Data type declarations*/
typedef struct{
    pin_config_t keypad_row_pins[ECU_KEYPAD_ROWS];
    pin_config_t keypad_column_pins[ECU_KEYPAD_COLUMNS];

}keypad_t;
/*section : Function declarations*/
Std_ReturnType keypad_initialize(const keypad_t *keypad_obj);
Std_ReturnType keypad_get_value(const keypad_t *keypad_obj , uint8 *value);
#endif	/* ECU_KEYPAD_H */

