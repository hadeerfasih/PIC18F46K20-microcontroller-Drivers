/* 
 * File:   ecu_relay_config.h
 * Author: Hadeer Shrif
 *
 * Created on August 13, 2024, 10:21 PM
 */

#ifndef ECU_RELAY_CONFIG_H
#define	ECU_RELAY_CONFIG_H

/*section : includes*/

/*section : Macro declarations*/

/*section : Macro function declarations*/

/*section : Data type declarations*/

/*section : Function declarations*/


#endif	/* ECU_RELAY_CONFIG_H */

