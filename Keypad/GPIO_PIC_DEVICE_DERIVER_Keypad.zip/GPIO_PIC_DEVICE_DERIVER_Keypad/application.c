/* 
 * File:   application.c
 * Author: Hadeer.Shrif
 *
 * Created on March 29, 2024, 12:15 AM
 */



#include "application.h"

uint8 keypad_value=ZERO_INIT;
Std_ReturnType ret=E_OK;
int main() {

    application_intialize();
    while(1){
        ret=keypad_get_value(&keypad1,&keypad_value);
        if(keypad_value=='7'){
            ret=led_turn_on(&led1);
        }  
        else if(keypad_value=='8'){
            ret=led_turn_off(&led1);
        }
    }
        
       
    return (EXIT_SUCCESS);
}


void application_intialize(void){
    ecu_layer_initialize();
   
}


