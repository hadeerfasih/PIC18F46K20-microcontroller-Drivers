/* 
 * File:   ecu_chr_lcd_cfg.h
 * Author: Hadeer Shrif
 *
 * Created on September 5, 2024, 7:22 PM
 */

#ifndef ECU_CHR_LCD_CFG_H
#define	ECU_CHR_LCD_CFG_H

//////////section : Includes//////////////////////////
#include "../../MCAL_LAYER/GPIO/hal_gpio.h"
/////////section : Macro declarations ////////////////////

/////////section : Macro function declarations ///////////

/////////section : Data type declarations ///////////////

/////////section : Function declarations ///////////////

#endif	/* ECU_CHR_LCD_CFG_H */

