/* 
 * File:   ecu_motor_config.h
 * Author: Hadeer Shrif
 *
 * Created on August 14, 2024, 6:18 PM
 */

#ifndef ECU_MOTOR_CONFIG_H
#define	ECU_MOTOR_CONFIG_H
/*section : includes*/
#include "../../MCAL_LAYER/GPIO/hal_gpio.h"
/*section : Macro declarations*/

/*section : Macro function declarations*/

/*section : Data type declarations*/

/*section : Function declarations*/

#endif	/* ECU_MOTOR_CONFIG_H */

