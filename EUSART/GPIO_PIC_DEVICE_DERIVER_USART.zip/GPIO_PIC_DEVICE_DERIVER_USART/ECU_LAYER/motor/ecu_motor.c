/* 
 * File:   ecu_motor.c
 * Author: Hadeer Shrif
 *
 * Created on August 14, 2024, 6:18 PM
 */
#include "ecu_motor.h"

/**
 * @brief
 * @param dc_motor
 * @return status of the function
 *         [E_OK]:the function done successfully 
 *         [E_NOT_OK]:the function has issue to perform this action
 */

static pin_config_t pin_obj_1;
static pin_config_t pin_obj_2;
Std_ReturnType dc_motor_initialize(const dc_motor_t *dc_motor){
    Std_ReturnType ret=E_OK;
    
    if(dc_motor==NULL){
        ret=E_NOT_OK;        
    }
    else{
       gpio_pin_intialize(&dc_motor->dc_motor_pin[0]);
       gpio_pin_intialize(&dc_motor->dc_motor_pin[1]);
    }
    return ret;
}
/**
 * @brief
 * @param dc_motor
 * @return status of the function
 *         [E_OK]:the function done successfully 
 *         [E_NOT_OK]:the function has issue to perform this action
 */
Std_ReturnType dc_motor_move_right(const dc_motor_t *dc_motor){
    Std_ReturnType ret=E_OK;
    
    if(dc_motor==NULL){
        ret=E_NOT_OK;        
    }
    else{
       gpio_pin_write_logic(&dc_motor->dc_motor_pin[0],HIGH);
       gpio_pin_write_logic(&dc_motor->dc_motor_pin[1],LOW);
    }
    return ret;
}
/**
 * @brief
 * @param dc_motor
 * @return status of the function
 *         [E_OK]:the function done successfully 
 *         [E_NOT_OK]:the function has issue to perform this action
 */
Std_ReturnType dc_motor_move_left(const dc_motor_t *dc_motor){
    Std_ReturnType ret=E_OK;
    
    if(dc_motor==NULL){
        ret=E_NOT_OK;        
    }
    else{
       gpio_pin_write_logic(&dc_motor->dc_motor_pin[0],LOW);
       gpio_pin_write_logic(&dc_motor->dc_motor_pin[1],HIGH);
    }
    return ret;
}
/**
 * @brief
 * @param dc_motor
 * @return status of the function
 *         [E_OK]:the function done successfully 
 *         [E_NOT_OK]:the function has issue to perform this action
 */
Std_ReturnType dc_motor_stop(const dc_motor_t *dc_motor){
    Std_ReturnType ret=E_OK;
    
    if(dc_motor==NULL){
        ret=E_NOT_OK;        
    }
    else{
       gpio_pin_write_logic(&dc_motor->dc_motor_pin[0],LOW);
       gpio_pin_write_logic(&dc_motor->dc_motor_pin[1],LOW);
    }
    return ret;
}