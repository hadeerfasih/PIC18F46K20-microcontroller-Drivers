/* 
 * File:   eeprom.c
 * Author: Hadeer Shrif
 *
 * Created on September 20, 2024, 9:45 PM
 */

#include "eeprom.h"

Std_ReturnType Data_EEPROM_WriteByte(uint16 bAdd, uint8 bData){
    Std_ReturnType ret=E_OK;
    /*Read the Interrupt Status "Enable or Disable" */
    uint8 Global_Interrupt_Status=INTCONbits.GIE;
    /*Update the Address Registers*/
    EEADRH=(uint8 )((bAdd >> 8)& 0x03);
    EEADR=(uint8 ) (bAdd & 0x0FF);
    /*Update the Data Registers*/
    EEDATA=bData; 
    /*Select Access data EEPROM Memory*/
    EECON1bits.EEPGD=ACCESS_EEPOM_PROGRAM_MEMORY;
    EECON1bits.CFGS=ACCESS_FLASH_EEPOM_MEMORY;
    /*Allows Write Cycles to Flash program/data EEPROM*/
    EECON1bits.WREN=ALLOW_WRITE_CYCLES_FLASH_EEPOM;
    /*Disable all interrupts "General interrupt"*/
    INTERRUPT_GlobalInterruptDisable();
    /*Write the required sequence :0x55->oxAA*/
    EECON2=0x55;
    EECON2=0xAA;
    /*Initiate a data EEPROM erase/write cycle*/
    EECON1bits.WR=INITIATE_DATA_EEPROM_WRITE_ERASE;
    /*Wait for write to completes*/
    while(EECON1bits.WR){}
    /*Inhibits write cycles to Flash program/data EEPROM*/
    EECON1bits.WREN=INHIBITS_WRITE_CYCLES_FLASH_EEPOM;
    /*Restore the Interrupt Status "Enable or Disable" */
    INTCONbits.GIE=Global_Interrupt_Status;
}
Std_ReturnType Data_EEPROM_ReadByte(uint16 bAdd, uint8 *bData){
   Std_ReturnType ret=E_OK;
   if(NULL==bData){
       ret=E_NOT_OK;
   }
   else{
       /*Update the Address Registers*/
        EEADRH=(uint8 )((bAdd >> 8)& 0x03);
        EEADR=(uint8 ) (bAdd & 0x0FF);
        /*Select Access data EEPROM Memory*/
        EECON1bits.EEPGD=ACCESS_EEPOM_PROGRAM_MEMORY;
        EECON1bits.CFGS=ACCESS_FLASH_EEPOM_MEMORY;
        /*Initiate a data EEPROM read cycle*/
        EECON1bits.RD=INITIATE_DATA_EEPROM_READ;
        Nop(); //give small delay time "to give time to the read operation"
        Nop();
        /*Return data*/
        *bData=EEDATA;
   }
   return ret;

}