/* 
 * File:   hal_usart_cfg.c
 * Author: Hadeer Shif
 *
 * Created on September 23, 2024, 10:18 PM
 */
#include "hal_usart.h"
/**
 * 
 * @param eusart
 * @return 
 */
static Std_ReturnType EUSART_Baud_Rate_Calculation(const usart_t *eusart );
static Std_ReturnType EUSART_ASYNC_TX_Init(const usart_t *eusart);
static Std_ReturnType EUSART_ASYNC_RX_Init(const usart_t *eusart);

#if EUSART_TX_INTERRUPT_FEATURE_ENABLE==INTERRUPT_FEATURE_ENABLE
static void(* EUSART_TXInterruptHandler)(void)=NULL;
#endif

#if EUSART_RX_INTERRUPT_FEATURE_ENABLE==INTERRUPT_FEATURE_ENABLE
static void(* EUSART_RXInterruptHandler)(void)=NULL;
static void(* EUSART_FramingErrorHandler)(void)=NULL;
static void(* EUSART_OverrunErrorHandler)(void)=NULL;
#endif

Std_ReturnType EUSART_ASYNC_Init(const usart_t *eusart){
    Std_ReturnType ret=E_OK;
    
    if(eusart==NULL){
        ret=E_NOT_OK;        
    }
    else{
        /*EUSART Module disable*/
        RCSTAbits.SPEN=EUSART_MODULE_DISABLE;
        TRISCbits.RC6=1;
        TRISCbits.RC7=1;
        /*Baud Rate config & SYNC bit config*/
        ret=EUSART_Baud_Rate_Calculation(eusart);
        ret=EUSART_ASYNC_TX_Init(eusart);
        ret=EUSART_ASYNC_RX_Init(eusart);
        /*EUSART Module enable*/
        RCSTAbits.SPEN=EUSART_MODULE_ENABLE;
        
    }
    return ret;

}
/**
 * 
 * @param eusart
 * @return 
 */
Std_ReturnType EUSART_ASYNC_DeInit(const usart_t *eusart){
    Std_ReturnType ret=E_OK;
    
    if(eusart==NULL){
        ret=E_NOT_OK;        
    }
    else{
        /*EUSART Module disable*/
        RCSTAbits.SPEN=EUSART_MODULE_DISABLE;
    }
    return ret;

}
Std_ReturnType EUSART_ASYNC_ReadByteNonBlocking(uint8 *data){
    Std_ReturnType ret=E_OK;
    
    if(data==NULL){
        ret=E_NOT_OK;        
    }
    else{
        if(PIR1bits.RCIF==1){
            *data=RCREG;   //reading data clears receive interrupt flag to avoid recursive interrupt
        }
        else{ //there is no data
            ret=E_NOT_OK; 
        }
    }
    return ret;
}
/**
 * 
 * @param eusart
 * @param data
 * @return 
 */
Std_ReturnType EUSART_ASYNC_ReadByteBlocking( uint8 *data){
    Std_ReturnType ret=E_OK;
    
    if(data==NULL){
        ret=E_NOT_OK;        
    }
    else{
        while(!PIR1bits.RCIF){} //check if there is a received data
        *data=RCREG;
    }
    return ret;

}

Std_ReturnType EUSART_ASYNC_RX_Restart(void){  //it will be called incase of overrun error to restart 
    Std_ReturnType ret=E_OK;
    RCSTAbits.CREN=0; /*disable receiver*/
    RCSTAbits.CREN=1; /*enable receiver*/
    return ret;
}
/**
 * 
 * @param eusart
 * @param data
 * @return 
 */
Std_ReturnType EUSART_ASYNC_WriteByteBlocking(uint8 data){
    Std_ReturnType ret=E_OK;
    

        while(!TXSTAbits.TRMT){ //ensure that shift register is not full
        
        }
#if EUSART_TX_INTERRUPT_FEATURE_ENABLE==INTERRUPT_FEATURE_ENABLE
        EUSART_TX_InterruptEnable(); //interrupt enable because it was disabled during transmitting in this function "EUSART_TX_ISR"
#endif
        TXREG=data;
 
    return ret;

}
/**
 * 
 * @param data
 * @param str_length
 * @return 
 */
Std_ReturnType EUSART_ASYNC_WriteStringBlocking(uint8 *data,uint16 str_length){
    Std_ReturnType ret=E_OK;
    uint16 char_counter=ZERO_INIT;
    if(data==NULL){
        ret=E_NOT_OK;        
    }
    else{
        for(char_counter=ZERO_INIT; char_counter < str_length; char_counter++){
            ret=EUSART_ASYNC_WriteByteBlocking(data[char_counter]);
        }
    }
    return ret;  
}

static Std_ReturnType EUSART_Baud_Rate_Calculation(const usart_t *eusart ){
    Std_ReturnType ret=E_OK;
    float Baud_Rtae_Temp=0;
    if(eusart==NULL){
        ret=E_NOT_OK;        
    }
    else{
        switch(eusart->baudrate_gen_config){
            case BAUDRATE_ASYN_8BIT_LOW_SPEED:
                TXSTAbits.SYNC=EUSART_ASYNCHRONOUS_MODE;
                TXSTAbits.BRGH=EUSART_ASYNCHRONOUS_LOW_SPEED;
                BAUDCONbits.BRG16=EUSART_08BIT_BAUDRATE_GEN;
                Baud_Rtae_Temp=((_XTAL_FREQ/(float)eusart->baudrate)/64)-1;//buad rate formula from data sheet  
                break;
            case BAUDRATE_ASYN_8BIT_HIGH_SPEED:
                TXSTAbits.SYNC=EUSART_ASYNCHRONOUS_MODE;
                TXSTAbits.BRGH=EUSART_ASYNCHRONOUS_HIGH_SPEED;
                BAUDCONbits.BRG16=EUSART_08BIT_BAUDRATE_GEN;
                Baud_Rtae_Temp=((_XTAL_FREQ/(float)eusart->baudrate)/16)-1;
                break;
            case BAUDRATE_ASYN_16BIT_LOW_SPEED:
                TXSTAbits.SYNC=EUSART_ASYNCHRONOUS_MODE;
                TXSTAbits.BRGH=EUSART_ASYNCHRONOUS_LOW_SPEED;
                BAUDCONbits.BRG16=EUSART_16BIT_BAUDRATE_GEN;
                Baud_Rtae_Temp=((_XTAL_FREQ/(float)eusart->baudrate)/16)-1;
                break;
            case BAUDRATE_ASYN_16BIT_HIGH_SPEED:
                TXSTAbits.SYNC=EUSART_ASYNCHRONOUS_MODE;
                TXSTAbits.BRGH=EUSART_ASYNCHRONOUS_HIGH_SPEED;
                BAUDCONbits.BRG16=EUSART_16BIT_BAUDRATE_GEN;
                Baud_Rtae_Temp=((_XTAL_FREQ/(float)eusart->baudrate)/4)-1;
                break;
            case BAUDRATE_SYN_8BIT:
                TXSTAbits.SYNC=EUSART_SYNCHRONOUS_MODE;
                BAUDCONbits.BRG16=EUSART_08BIT_BAUDRATE_GEN;
                Baud_Rtae_Temp=((_XTAL_FREQ/(float)eusart->baudrate)/4)-1;
                break;
            case BAUDRATE_SYN_16BIT:
                TXSTAbits.SYNC=EUSART_SYNCHRONOUS_MODE;
                BAUDCONbits.BRG16=EUSART_16BIT_BAUDRATE_GEN;
                Baud_Rtae_Temp=((_XTAL_FREQ/(float)eusart->baudrate)/4)-1;
                break;
            default:
                break;
        }
        SPBRG=(uint8)(uint32)Baud_Rtae_Temp; //take the first 8bits 
        SPBRGH=(uint8)((uint32)Baud_Rtae_Temp>>8);
    }
    return ret;

}


static Std_ReturnType EUSART_ASYNC_TX_Init(const usart_t *eusart){
    Std_ReturnType ret=E_OK;
    
    if(eusart==NULL){
        ret=E_NOT_OK;        
    }
    else{
        if(EUSART_ASYNCHRONOUS_TX_ENABLE==eusart->usart_tx_cfg.usart_tx_enable){
            TXSTAbits.TXEN=EUSART_ASYNCHRONOUS_TX_ENABLE;
            EUSART_TXInterruptHandler=eusart->EUSART_TXDefaultInterruptHandler;
            /*EUSART Transmit Interrupt configuration*/
            if(eusart->usart_tx_cfg.usart_tx_interrupt_enable==EUSART_ASYNCHRONOUS_INTERRUPT_TX_ENABLE){
                PIE1bits.TXIE=EUSART_ASYNCHRONOUS_INTERRUPT_TX_ENABLE;
#if EUSART_TX_INTERRUPT_FEATURE_ENABLE==INTERRUPT_FEATURE_ENABLE
                EUSART_TX_InterruptEnable(); 
#if INTERRUPT_PRIORITY_LEVELS_ENABLE==INTERRUPT_FEATURE_ENABLE
            INTERRUPT_PriorityLevelEnable();
            if(INTERRUPT_LOW_PRIORITY==eusart->usart_tx_cfg.usart_tx_interrupt_priority){
                //this macro will enable low priority global interrupts
                INTERRUPT_GlobalInterruptLowEnable();
                //this routine set the TX internal interrupt priority to be Low priority
                EUSART_TX_LowPrioritySet();
            }
            else if(INTERRUPT_HIGH_PRIORITY==eusart->usart_tx_cfg.usart_tx_interrupt_priority){
                //this macro will enable high priority global interrupts
                INTERRUPT_GlobalInterruptHighEnable();
                ///this routine set the TX internal interrupt priority to be High priority
                EUSART_TX_HighPrioritySet();
            }
            else{/*nothing*/}
                
#else
                INTERRUPT_GlobalInterruptEnable();
                INTERRUPT_PeripheralInteruuptEnable();
#endif                
#endif
            }
            else if(eusart->usart_tx_cfg.usart_tx_interrupt_enable==EUSART_ASYNCHRONOUS_INTERRUPT_TX_DISABLE){
                PIE1bits.TXIE=EUSART_ASYNCHRONOUS_INTERRUPT_TX_DISABLE;
            }
            else{/*nothing*/}

            /*EUSART 9Bit Transmit configuration*/
            if(eusart->usart_tx_cfg.usart_tx_9bit_enable==EUSART_ASYNCHRONOUS_9Bit_TX_ENABLE){
                TXSTAbits.TX9=EUSART_ASYNCHRONOUS_9Bit_TX_ENABLE;
            }
            else if(eusart->usart_tx_cfg.usart_tx_9bit_enable==EUSART_ASYNCHRONOUS_9Bit_TX_DISABLE){
                TXSTAbits.TX9=EUSART_ASYNCHRONOUS_9Bit_TX_DISABLE ;
            }
            else{/*nothing*/}
        }
        else{/*nothing*/}
    }
    return ret;

}

static Std_ReturnType EUSART_ASYNC_RX_Init(const usart_t *eusart){
    Std_ReturnType ret=E_OK;
    
    if(eusart==NULL){
        ret=E_NOT_OK;        
    }
    else{
        if(EUSART_ASYNCHRONOUS_RX_ENABLE==eusart->usart_rx_cfg.usart_rx_enable){
            RCSTAbits.CREN=EUSART_ASYNCHRONOUS_RX_ENABLE;
            EUSART_RXInterruptHandler=eusart->EUSART_RXDefaultInterruptHandler;
            EUSART_FramingErrorHandler=eusart->EUSART_FramingErrorHandler;
            EUSART_OverrunErrorHandler=eusart->EUSART_OverrunErrorHandler;
            /*EUSART Receiver Interrupt configuration*/
            if(eusart->usart_rx_cfg.usart_rx_interrupt_enable==EUSART_ASYNCHRONOUS_INTERRUPT_RX_ENABLE){
                PIE1bits.RCIE=EUSART_ASYNCHRONOUS_INTERRUPT_RX_ENABLE;
#if EUSART_RX_INTERRUPT_FEATURE_ENABLE==INTERRUPT_FEATURE_ENABLE
                EUSART_RX_InterruptEnable();     
#if INTERRUPT_PRIORITY_LEVELS_ENABLE==INTERRUPT_FEATURE_ENABLE
            INTERRUPT_PriorityLevelEnable();
            if(INTERRUPT_LOW_PRIORITY==eusart->usart_rx_cfg.usart_rx_interrupt_priority){
                //this macro will enable low priority global interrupts
                INTERRUPT_GlobalInterruptLowEnable();
                //this routine set the RX internal interrupt priority to be Low priority
                EUSART_RX_LowPrioritySet();
            }
            else if(INTERRUPT_HIGH_PRIORITY==eusart->usart_rx_cfg.usart_rx_interrupt_priority){
                //this macro will enable high priority global interrupts
                INTERRUPT_GlobalInterruptHighEnable();
                ///this routine set the RX internal interrupt priority to be High priority
                EUSART_RX_HighPrioritySet();
            }
            else{/*nothing*/}
                
#else
                INTERRUPT_GlobalInterruptEnable();
                INTERRUPT_PeripheralInteruuptEnable();
#endif                  
#endif    
            }
            else if(eusart->usart_rx_cfg.usart_rx_interrupt_enable==EUSART_ASYNCHRONOUS_INTERRUPT_RX_DISABLE){
                PIE1bits.RCIE=EUSART_ASYNCHRONOUS_INTERRUPT_RX_DISABLE;
            }
            else{/*nothing*/}

            /*EUSART 9Bit Receiver configuration*/
            if(eusart->usart_rx_cfg.usart_rx_9bit_enable==EUSART_ASYNCHRONOUS_9Bit_RX_ENABLE){
                RCSTAbits.RX9=EUSART_ASYNCHRONOUS_9Bit_RX_ENABLE;
            }
            else if(eusart->usart_rx_cfg.usart_rx_9bit_enable==EUSART_ASYNCHRONOUS_9Bit_RX_DISABLE){
                RCSTAbits.RX9=EUSART_ASYNCHRONOUS_9Bit_RX_DISABLE ;
            }
            else{/*nothing*/}
        }
        else{/*nothing*/}
    }
    return ret;

}


void EUSART_TX_ISR(void){
  if(EUSART_TXInterruptHandler){
      EUSART_TX_InterruptDisable(); //interrupt disable
      EUSART_TXInterruptHandler();
  }else{/*nothing*/}
}
void EUSART_RX_ISR(void){
    if(EUSART_RXInterruptHandler){
      EUSART_RXInterruptHandler();
    }else{/*nothing*/}
    
    if(EUSART_FramingErrorHandler){
      EUSART_FramingErrorHandler();
    }else{/*nothing*/}
    
    if(EUSART_OverrunErrorHandler){
      EUSART_OverrunErrorHandler();
    }else{/*nothing*/}
}