/* 
 * File:   hal_usart_cfg.h
 * Author: Hadeer Shif
 *
 * Created on September 23, 2024, 10:18 PM
 */

#ifndef HAL_USART_CFG_H
#define	HAL_USART_CFG_H

/*==================section : includes==========================*/
#include "../GPIO/hal_gpio.h"
#include "../GPIO/../mcal_std_types.h"
#include "../proc/pic18f4620.h"
#include "../Interrupt/mcal_internal_interrupt.h"
/*==================section : Macro declarations===============*/

/*==================section : Macro function declarations=====*/

/*==================section : Data type declarations==========*/

/*==================section : Function declarations==========*/

#endif	/* HAL_USART_CFG_H */

