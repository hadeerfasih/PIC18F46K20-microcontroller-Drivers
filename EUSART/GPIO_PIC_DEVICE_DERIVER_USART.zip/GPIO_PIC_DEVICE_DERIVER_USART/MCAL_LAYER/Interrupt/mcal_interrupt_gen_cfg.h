/* 
 * File:   mcal_interrupt_gen_cfg.h
 * Author: Hadeer Shrif
 *
 * Created on September 17, 2024, 5:50 PM
 */

#ifndef MCAL_INTERRUPT_GEN_CFG_H
#define	MCAL_INTERRUPT_GEN_CFG_H

/*section : includes*/

/*section : Macro declarations*/
#define INTERRUPT_FEATURE_ENABLE  1U
//#define INTERRUPT_PRIORITY_LEVELS_ENABLE             INTERRUPT_FEATURE_ENABLE
#define EXTERNAL_INTERRUPT_INTx_FEATURE_ENABLE       INTERRUPT_FEATURE_ENABLE
#define EXTERNAL_INTERRUPT_OnChange_FEATURE_ENABLE   INTERRUPT_FEATURE_ENABLE

#define EUSART_TX_INTERRUPT_FEATURE_ENABLE           INTERRUPT_FEATURE_ENABLE 
#define EUSART_RX_INTERRUPT_FEATURE_ENABLE           INTERRUPT_FEATURE_ENABLE 
/*section : Macro function declarations*/

/*section : Data type declarations*/
typedef enum{
    INTERRUPT_LOW_PRIORITY=0,
    INTERRUPT_HIGH_PRIORITY        
}interrupt_priority_cfg;
/*section : Function declarations*/

#endif	/* MCAL_INTERRUPT_GEN_CFG_H */

