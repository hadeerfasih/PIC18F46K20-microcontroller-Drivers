/* 
 * File:   mcal_internal_interrupt.h
 * Author: Hadeer Shrif
 *
 * Created on September 17, 2024, 4:05 PM
 */

#ifndef MCAL_INTERNAL_INTERRUPT_H
#define	MCAL_INTERNAL_INTERRUPT_H

/*section : includes*/
#include "mcal_interrupt_config.h"
/*section : Macro declarations*/
#if EUSART_TX_INTERRUPT_FEATURE_ENABLE==INTERRUPT_FEATURE_ENABLE
/*This macro clears the interrupt enable for the EUSART module*/
#define EUSART_TX_InterruptDisable()      (PIE1bits.TXIE=0)
/*This macro set the interrupt enable for the EUSART module*/
#define EUSART_TX_InterruptEnable()      (PIE1bits.TXIE=1)
#if INTERRUPT_PRIORITY_LEVELS_ENABLE==INTERRUPT_FEATURE_ENABLE
/*This macro set theEUSART module Interrupt priority to be High priority*/
#define EUSART_TX_HighPrioritySet()       (IPR1bits.TXIP=1)
/*This macro set theEUSART module Interrupt priority to be Low priority*/
#define EUSART_TX_LowPrioritySet()        (IPR1bits.TXIP=0)
#endif
#endif

#if EUSART_RX_INTERRUPT_FEATURE_ENABLE==INTERRUPT_FEATURE_ENABLE
/*This macro clears the interrupt enable for the EUSART module*/
#define EUSART_RX_InterruptDisable()      (PIE1bits.RCIE=0)
/*This macro set the interrupt enable for the EUSART module*/
#define EUSART_RX_InterruptEnable()      (PIE1bits.RCIE=1)
#if INTERRUPT_PRIORITY_LEVELS_ENABLE==INTERRUPT_FEATURE_ENABLE
/*This macro set theEUSART module Interrupt priority to be High priority*/
#define EUSART_RX_HighPrioritySet()       (IPR1bits.RCIP=1)
/*This macro set theEUSART module Interrupt priority to be Low priority*/
#define EUSART_RX_LowPrioritySet()        (IPR1bits.RCIP=0)
#endif
#endif
/*section : Macro function declarations*/

/*section : Data type declarations*/

/*section : Function declarations*/


#endif	/* MCAL_INTERNAL_INTERRUPT_H */

