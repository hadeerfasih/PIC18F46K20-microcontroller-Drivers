/* 
 * File:   application.h
 * Author: Hadeer.Shrif
 *
 * Created on March 29, 2024, 5:48 PM
 */

#ifndef APPLICATION_H
#define	APPLICATION_H
//////////section : Includes//////////////////////////
#include "ECU_LAYER/LED/ecu_led.h"

/////////section : Macro declarations ////////////////////

/////////section : Macro function declarations ///////////

/////////section : Data type declarations ///////////////

/////////section : Function declarations ///////////////

void application_intialize(void);
#endif	/* APPLICATION_H */

