/* 
 * File:   application.c
 * Author: Hadeer.Shrif
 *
 * Created on March 29, 2024, 12:15 AM
 */



#include "application.h"

pin_config_t led_1={
.port=PORTC_INDEX,
.pin=PIN0,
.direction=OUTPUT,
.logic=LOW
};

pin_config_t led_2={
.port=PORTC_INDEX,
.pin=PIN1,
.direction=OUTPUT,
.logic=LOW
};

pin_config_t led_3={
.port=PORTC_INDEX,
.pin=PIN2,
.direction=OUTPUT,
.logic=LOW
};

pin_config_t btn_1={
.port=PORTD_INDEX,
.pin=PIN0,
.direction=INPUT,
.logic=LOW
};


/*
 * 
 */

Std_ReturnType ret=E_NOT_OK;
direction_t led1_st;
logic_t btn_1_st;

uint8 portc_direction_status;
uint8 portc_read_logic;
int main() {

    application_intialize();
    while(1){
        ret=gpio_port_toggle_logic(PORTC_INDEX);
        unsigned int i;
        for(i=50000;i>0;i--){

        }
/////////////////////////////////pin trials////////////////
//        gpio_pin_toggle_logic(&led_1);
//        unsigned int i;
//        for(i=5000;i>0;i--){
        
       // }
//        ret=gpio_pin_read_logic(&btn_1,&btn_1_st);
//        if(btn_1_st==HIGH){
//            ret=gpio_pin_write_logic(&led_1,HIGH);
//            ret=gpio_pin_write_logic(&led_2,HIGH);
//            ret=gpio_pin_write_logic(&led_3,HIGH);
//        }
//        else{
//            ret=gpio_pin_write_logic(&led_1,LOW);
//            ret=gpio_pin_write_logic(&led_2,LOW);
//            ret=gpio_pin_write_logic(&led_3,LOW);
//        }
        
    }
    return (EXIT_SUCCESS);
}

void application_intialize(void){
   
    ret=gpio_port_direction_intialize(PORTC_INDEX,0x00);
    gpio_port_write_logic(PORTC_INDEX,0x55);
    ret=gpio_port_get_direction_status(PORTC_INDEX,&portc_direction_status);
    ret=gpio_port_read_logic(PORTC_INDEX,&portc_read_logic);
    unsigned int i;
    for(i=50000;i>0;i--){
        
    }
    gpio_port_write_logic(PORTC_INDEX,0xAA);
    ret=gpio_port_read_logic(PORTC_INDEX,&portc_read_logic);
    
/////////////////////pin trials/////////////////////////////////
//    ret=gpio_pin_intialize(&btn_1);
//    
//    ret=gpio_pin_intialize(&led_1); 
//    ret=gpio_pin_intialize(&led_2);
//    ret=gpio_pin_intialize(&led_3);
///////////////////////////////////////////////////////////////
}