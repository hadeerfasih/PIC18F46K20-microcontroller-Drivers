/* 
 * File:   ecu_led.h
 * Author: Hadeer.Shrif
 *
 * Created on March 29, 2024, 5:34 PM
 */

#ifndef ECU_LED_H
#define	ECU_LED_H
/////////section : includes///////////////////////////////
#include "../../MCAL_LAYER/GPIO/hal_gpio.h"
/////////section : Macro declarations ////////////////////

/////////section : Macro function declarations ///////////

/////////section : Data type declarations ///////////////

/////////section : Function declarations ///////////////

#endif	/* ECU_LED_H */

