/* 
 * File:   hal_gpio_config.h
 * Author: pc
 *
 * Created on August 5, 2024, 7:37 PM
 */

#ifndef HAL_GPIO_CONFIG_H
#define	HAL_GPIO_CONFIG_H

#define ENABLE  0x01
#define DISABLE 0x00

#endif	/* HAL_GPIO_CONFIG_H */

