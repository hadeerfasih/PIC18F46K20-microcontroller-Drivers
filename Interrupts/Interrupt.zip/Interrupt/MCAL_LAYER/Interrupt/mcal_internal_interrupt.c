/* 
 * File:   mcal_internal_interrupt.c
 * Author: Hadeer Shrif
 *
 * Created on September 17, 2024, 4:05 PM
 */
#include "mcal_internal_interrupt.h"