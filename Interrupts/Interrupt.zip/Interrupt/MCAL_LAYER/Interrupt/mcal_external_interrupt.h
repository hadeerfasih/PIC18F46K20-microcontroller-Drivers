/* 
 * File:   mcal_external_interrupt.h
 * Author: Hadeer Shrif
 *
 * Created on September 17, 2024, 4:05 PM
 */

#ifndef MCAL_EXTERNAL_INTERRUPT_H
#define	MCAL_EXTERNAL_INTERRUPT_H

/*section : includes*/
#include "mcal_interrupt_config.h"
/*section : Macro declarations*/

/*section : Macro function declarations*/
#if EXTERNAL_INTERRUPT_INTx_FEATURE_ENABLE == INTERRUPT_FEATURE_ENABLE

//this routine sets the interrupt enable for the external interrupt, INT0
#define EXT_INT0_INTERRUPTEnable()      (INTCONbits.INT0IE=1)
//this routine sets the interrupt disable for the external interrupt, INT0
#define EXT_INT0_INTERRUPTDisable()     (INTCONbits.INT0IE=0)

//this routine clears the interrupt flag  for the external interrupt, INT0
#define EXT_INT0_INTERRUPTFlagClear()   (INTCONbits.INT0IF=0)

//this routine set the edge detect of the external interrupt to negative edge, INT0
#define EXT_INT0_RisingEdgeSet()   (INTCON2bits.INTEDG0=1)
//this routine set the edge detect of the external interrupt to positive negative edge, INT0
#define EXT_INT0_FallingEdgeSet()   (INTCON2bits.INTEDG0=0)




//this routine sets the interrupt enable for the external interrupt, INT1
#define EXT_INT1_INTERRUPTEnable()      (INTCON3bits.INT1IE=1)
//this routine clear the interrupt disable for the external interrupt, INT1
#define EXT_INT1_INTERRUPTDisable()     (INTCON3bits.INT1IE=0)

//this routine clears the interrupt flag  for the external interrupt, INT1
#define EXT_INT1_INTERRUPTFlagClear()   (INTCON3bits.INT1IF=0)

//this routine set the edge detect of the external interrupt to negative edge, INT1
#define EXT_INT1_RisingEdgeSet()   (INTCON2bits.INTEDG1=1)
//this routine set the edge detect of the external interrupt to positive negative edge, INT1
#define EXT_INT1_FallingEdgeSet()   (INTCON2bits.INTEDG1=0)




//this routine sets the interrupt enable for the external interrupt, INT2
#define EXT_INT2_INTERRUPTEnable()      (INTCON3bits.INT2IE=1)
//this routine clear the interrupt disable for the external interrupt, INT2
#define EXT_INT2_INTERRUPTDisable()     (INTCON3bits.INT2IE=0)

//this routine clears the interrupt flag  for the external interrupt, INT2
#define EXT_INT2_INTERRUPTFlagClear()   (INTCON3bits.INT2IF=0)

//this routine set the edge detect of the external interrupt to negative edge, INT2
#define EXT_INT2_RisingEdgeSet()   (INTCON2bits.INTEDG2=1)
//this routine set the edge detect of the external interrupt to positive negative edge, INT2
#define EXT_INT2_FallingEdgeSet()   (INTCON2bits.INTEDG2=0)



#if INTERRUPT_PRIORITY_LEVELS_ENABLE==INTERRUPT_FEATURE_ENABLE
//this routine set the INT1 external interrupt priority to be High priority, INT1
#define EXT_INT1_HighPrioritySet()   (INTCON3bits.INT1IP=1)
//this routine set the INT1 external interrupt priority to be LOW priority, INT1
#define EXT_INT1_LowPrioritySet()   (INTCON3bits.INT1IP=0)

//this routine set the INT2 external interrupt priority to be High priority, INT2
#define EXT_INT2_HighPrioritySet()   (INTCON3bits.INT2IP=1)
//this routine set the INT2 external interrupt priority to be LOW priority, INT2
#define EXT_INT2_LowPrioritySet()   (INTCON3bits.INT2IP=0)
#endif

#endif



#if EXTERNAL_INTERRUPT_OnChange_FEATURE_ENABLE == INTERRUPT_FEATURE_ENABLE
//this routine sets the interrupt disable for the external interrupt, RBx 
#define EXT_RBx_InterruptDisable()      (INTCONbits.RBIE=0)
//this routine sets the interrupt enable for the external interrupt, RBx
#define EXT_RBx_InterruptEnable()      (INTCONbits.RBIE=1)

//this routine clears the interrupt flag  for the external interrupt, RBx
#define EXT_RBx_InterruptFlagClear()      (INTCONbits.RBIF=0)

#if INTERRUPT_PRIORITY_LEVELS_ENABLE==INTERRUPT_FEATURE_ENABLE

//this routine set the RBx external interrupt priority to be High priority, RBx
#define EXT_RBx_HighPrioritySet()   (INTCON2bits.RBIP=1)
//this routine set the RBx external interrupt priority to be LOW priority, RBx
#define EXT_RBx_LowPrioritySet()   (INTCON2bits.RBIP=0)

#endif
#endif
/*section : Data type declarations*/
typedef enum{
INTERRUPT_FALLING_EDGE=0,
INTERRUPT_RISING_EDGE       
}interrupt_INTx_edge;

typedef enum{
INTERRUPT_EXTERNAL_INT0=0,
INTERRUPT_EXTERNAL_INT1,
INTERRUPT_EXTERNAL_INT2       
}interrupt_INTx_src;


typedef struct {
    void(* EXT_InterruptHandler)(void);  //call back
    pin_config_t mcu_pin;
    interrupt_INTx_edge edge;
    interrupt_INTx_src  source;
    interrupt_priority_cfg priority;
}interrupt_INTx_t;

typedef struct {
    void(* EXT_InterruptHandler_HIGH)(void);  //call back
    void(* EXT_InterruptHandler_LOW)(void);  //call back
    pin_config_t mcu_pin;
    interrupt_priority_cfg priority;
}interrupt_RBx_t;
/*section : Function declarations*/
/**
 * 
 * @param int_obj
 * @return 
 */
Std_ReturnType Interrupt_INTx_Init(const interrupt_INTx_t *int_obj);
/**
 * 
 * @param int_obj
 * @return 
 */
Std_ReturnType Interrupt_INTx_DeInit(const interrupt_INTx_t *int_obj);
/**
 * 
 * @param int_obj
 * @return 
 */
Std_ReturnType Interrupt_RBx_Init(const interrupt_RBx_t *int_obj);
/**
 * 
 * @param int_obj
 * @return 
 */
Std_ReturnType Interrupt_RBx_DeInit(const interrupt_RBx_t *int_obj);

#endif	/* MCAL_EXTERNAL_INTERRUPT_H */

