/* 
 * File:   mcal_interrupt_manager.h
 * Author: Hadeer Shrif
 *
 * Created on September 17, 2024, 4:06 PM
 */

#ifndef MCAL_INTERRUPT_MANAGER_H
#define	MCAL_INTERRUPT_MANAGER_H

/*section : includes*/
#include "mcal_interrupt_config.h"
#include "../../ECU_LAYER/LED/ecu_led.h"
/*section : Macro declarations*/

/*section : Macro function declarations*/

/*section : Data type declarations*/

/*section : Function declarations*/
void INT0_ISR(void);
void INT1_ISR(void);
void INT2_ISR(void);
void RB4_ISR(uint8 RB4_source);
void RB5_ISR(uint8 RB5_source);
void RB6_ISR(uint8 RB6_source);
void RB7_ISR(uint8 RB7_source);


led_t led2={
.port_name=PORTC_INDEX,
.pin=PIN1,
.led_status=LOW
};
#endif	/* MCAL_INTERRUPT_MANAGER_H */

