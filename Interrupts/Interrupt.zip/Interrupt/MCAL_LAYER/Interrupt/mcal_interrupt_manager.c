/* 
 * File:   mcal_interrupt_manager.c
 * Author: Hadeer Shrif
 *
 * Created on September 17, 2024, 4:06 PM
 */
#include "mcal_interrupt_manager.h"

static volatile uint8 RB4_Flag=1;
static volatile uint8 RB5_Flag=1;
static volatile uint8 RB6_Flag=1;
static volatile uint8 RB7_Flag=1;

#if INTERRUPT_PRIORITY_LEVELS_ENABLE==INTERRUPT_FEATURE_ENABLE
//check here if the interrupt you configured it as high priority
void __interrupt() InterruptManagerHigh(void){
    if((INTERUUPT_ENABLE==INTCONbits.INT0IE)&&(INTERRUPT_OCCUR==INTCONbits.INT0IF)){
        INT0_ISR();
    }
    else{/*nothing*/}
    if((INTERUUPT_ENABLE==INTCON3bits.INT2IE)&&(INTERRUPT_OCCUR==INTCON3bits.INT2IF)){
        INT2_ISR();
    }
    else{/*nothing*/}
}
//check here if the interrupt you configured it as low priority
void __interrupt(low_priority) InterruptManagerLow(void){
    if((INTERUUPT_ENABLE==INTCON3bits.INT1IE)&&(INTERRUPT_OCCUR==INTCON3bits.INT1IF)){
        INT1_ISR();
    }
    else{/*nothing*/}
}
#else 
void __interrupt() InterruptManagerHigh(void){
//    led_initialize(&led2);
//    led_turn_on(&led2);
    
    if((INTERUUPT_ENABLE==INTCONbits.INT0IE)&&(INTERRUPT_OCCUR==INTCONbits.INT0IF)){
        INT0_ISR();
    }
    else{/*nothing*/}
    if((INTERUUPT_ENABLE==INTCON3bits.INT1IE)&&(INTERRUPT_OCCUR==INTCON3bits.INT1IF)){
        INT1_ISR();
    }
    else{/*nothing*/}
    if((INTERUUPT_ENABLE==INTCON3bits.INT2IE)&&(INTERRUPT_OCCUR==INTCON3bits.INT2IF)){
        INT2_ISR();
    }
    else{/*nothing*/}
    
    /*================== PortB External On Change Interrupt Start ========================== */ 
    
    if((INTERUUPT_ENABLE==INTCONbits.RBIE)&&(INTERRUPT_OCCUR==INTCONbits.RBIF)&&(PORTBbits.RB4==HIGH)&&( RB4_Flag==1)){
        RB4_Flag=0;
        RB4_ISR(0);
    }
    else{/*nothing*/}
    if((INTERUUPT_ENABLE==INTCONbits.RBIE)&&(INTERRUPT_OCCUR==INTCONbits.RBIF)&&(PORTBbits.RB4==LOW)&&( RB4_Flag==0)){
        RB4_Flag=1;
        RB4_ISR(1);
    }
    else{/*nothing*/}
    if((INTERUUPT_ENABLE==INTCONbits.RBIE)&&(INTERRUPT_OCCUR==INTCONbits.RBIF)&&(PORTBbits.RB5==HIGH)&&( RB5_Flag==1)){
        RB5_Flag=0;
        RB5_ISR(0);
    }
    else{/*nothing*/}
    if((INTERUUPT_ENABLE==INTCONbits.RBIE)&&(INTERRUPT_OCCUR==INTCONbits.RBIF)&&(PORTBbits.RB5==LOW)&&( RB5_Flag==0)){
        RB5_Flag=1;
        RB5_ISR(1);
    }
    else{/*nothing*/}
    
    if((INTERUUPT_ENABLE==INTCONbits.RBIE)&&(INTERRUPT_OCCUR==INTCONbits.RBIF)&&(PORTBbits.RB6==HIGH)&&( RB6_Flag==1)){
        RB6_Flag=0;
        RB6_ISR(0);
    }
    else{/*nothing*/}
    if((INTERUUPT_ENABLE==INTCONbits.RBIE)&&(INTERRUPT_OCCUR==INTCONbits.RBIF)&&(PORTBbits.RB6==LOW)&&( RB6_Flag==0)){
        RB6_Flag=1;
        RB6_ISR(1);
    }
    else{/*nothing*/}
    
    if((INTERUUPT_ENABLE==INTCONbits.RBIE)&&(INTERRUPT_OCCUR==INTCONbits.RBIF)&&(PORTBbits.RB7==HIGH)&&( RB7_Flag==1)){
        RB7_Flag=0;
        RB7_ISR(0);
    }
    else{/*nothing*/}
    if((INTERUUPT_ENABLE==INTCONbits.RBIE)&&(INTERRUPT_OCCUR==INTCONbits.RBIF)&&(PORTBbits.RB7==LOW)&&( RB7_Flag==0)){
        RB7_Flag=1;
        RB7_ISR(1);
    }
    else{/*nothing*/}
    /*================== PortB External On Change Interrupt End ========================== */
    
     
}
#endif