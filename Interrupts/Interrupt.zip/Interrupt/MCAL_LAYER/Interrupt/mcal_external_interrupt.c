/* 
 * File:   mcal_external_interrupt.c
 * Author: Hadeer Shrif
 *
 * Created on September 17, 2024, 4:05 PM
 */
#include "mcal_external_interrupt.h"
//void pointer to funtion point to the ISR application
static void(* INT0_InterruprHandler)(void)=NULL;
static void(* INT1_InterruprHandler)(void)=NULL;
static void(* INT2_InterruprHandler)(void)=NULL;

static void(* RB4_InterruprHandler_HIGH)(void)=NULL;
static void(* RB4_InterruprHandler_LOW)(void)=NULL;
static void(* RB5_InterruprHandler_HIGH)(void)=NULL;
static void(* RB5_InterruprHandler_LOW)(void)=NULL;
static void(* RB6_InterruprHandler_HIGH)(void)=NULL;
static void(* RB6_InterruprHandler_LOW)(void)=NULL;
static void(* RB7_InterruprHandler_HIGH)(void)=NULL;
static void(* RB7_InterruprHandler_LOW)(void)=NULL;

static Std_ReturnType Interrupt_INTx_Enable(const interrupt_INTx_t *int_obj);
static Std_ReturnType Interrupt_INTx_Disable(const interrupt_INTx_t *int_obj);
static Std_ReturnType Interrupt_INTx_Priority_Init(const interrupt_INTx_t *int_obj);
static Std_ReturnType Interrupt_INTx_Edge_Init(const interrupt_INTx_t *int_obj);
static Std_ReturnType Interrupt_INTx_Pin_Init(const interrupt_INTx_t *int_obj);
static Std_ReturnType Interrupt_INTx_Clear_Flag(const  interrupt_INTx_t *int_obj);
static Std_ReturnType INT0_set_InterruprHandler(void(* InterruprHandler)(void));
static Std_ReturnType INT1_set_InterruprHandler(void(* InterruprHandler)(void));
static Std_ReturnType INT2_set_InterruprHandler(void(* InterruprHandler)(void));
static Std_ReturnType Interrupt_INTx_set_InterruprHandler(const interrupt_INTx_t *int_obj);

static Std_ReturnType Interrupt_RBx_Enable(const interrupt_RBx_t *int_obj);
static Std_ReturnType Interrupt_RBx_Disable(const interrupt_RBx_t *int_obj);
static Std_ReturnType Interrupt_RBx_Priority_Init(const interrupt_RBx_t *int_obj);
static Std_ReturnType Interrupt_RBx_Pin_Init(const interrupt_RBx_t *int_obj);
/**
 * 
 * @param int_obj
 * @return 
 */
Std_ReturnType Interrupt_INTx_Init(const interrupt_INTx_t *int_obj){
    Std_ReturnType ret=E_OK;
    
    if(int_obj==NULL){
        ret=E_NOT_OK;        
    }
    else{
        /*Disable the External Interrupt*/
        ret=Interrupt_INTx_Disable(int_obj);
        /*Clear Interrupt Flag :External Interrupt did not occur*/
        ret=Interrupt_INTx_Clear_Flag(int_obj);
        /*Configure External Interrupt edge*/
         ret=Interrupt_INTx_Edge_Init(int_obj);
        /*Configure External Interrupt priority*/
         #if INTERRUPT_PRIORITY_LEVELS_ENABLE==INTERRUPT_FEATURE_ENABLE
         ret=Interrupt_INTx_Priority_Init(int_obj);
         #endif
        /*Configure External Interrupt I/O pin*/
         ret=Interrupt_INTx_Pin_Init(int_obj);
        /*Configure Default Interrupt CallBack*/
         ret=Interrupt_INTx_set_InterruprHandler(int_obj);
        /*Enable the External Interrupt*/
         ret=Interrupt_INTx_Enable(int_obj);
    }
    return ret;

}
void INT0_ISR(void){
    /*the INT0 external interrupt occurred (must be cleared in software )*/
    EXT_INT0_INTERRUPTFlagClear();
    /*code*/
    
    /*callback function gets called every time this ISR executes*/
    if(INT0_InterruprHandler)
    {
        INT0_InterruprHandler();
    }

}
void INT1_ISR(void){
    /*the INT1 external interrupt occurred (must be cleared in software )*/
    EXT_INT1_INTERRUPTFlagClear();
    /*code*/
    
    /*callback function gets called every time this ISR executes*/
    if(INT1_InterruprHandler)
    {
        INT1_InterruprHandler();
    }

}
void INT2_ISR(void){
    /*the INT2 external interrupt occurred (must be cleared in software )*/
    EXT_INT2_INTERRUPTFlagClear();
    /*code*/
    
    /*callback function gets called every time this ISR executes*/
    if(INT2_InterruprHandler)
    {
        INT2_InterruprHandler();
    }

}
/*External Interrupt RB4 MCAL Helper Function*/
void RB4_ISR(uint8 RB4_source){
    //this routine clears the interrupt flag  for the external interrupt, RBx
   EXT_RBx_InterruptFlagClear();
   if(0==RB4_source){
       if(RB4_InterruprHandler_HIGH)
       {
        RB4_InterruprHandler_HIGH();
       }
   }else if(1==RB4_source){
       if(RB4_InterruprHandler_LOW)
       {
        RB4_InterruprHandler_LOW();
       }
   }else{/*nothing*/}
   

}
/*External Interrupt RB5 MCAL Helper Function*/
void RB5_ISR(uint8 RB5_source){
    //this routine clears the interrupt flag  for the external interrupt, RBx
   EXT_RBx_InterruptFlagClear();
   if(0==RB5_source){
       if(RB5_InterruprHandler_HIGH)
       {
        RB5_InterruprHandler_HIGH();
       }
   }else if(1==RB5_source){
       if(RB5_InterruprHandler_LOW)
       {
        RB5_InterruprHandler_LOW();
       }
   }else{/*nothing*/}
   

}
/*External Interrupt RB6 MCAL Helper Function*/
void RB6_ISR(uint8 RB6_source){
    //this routine clears the interrupt flag  for the external interrupt, RBx
   EXT_RBx_InterruptFlagClear();
   if(0==RB6_source){
       if(RB6_InterruprHandler_HIGH)
       {
        RB6_InterruprHandler_HIGH();
       }
   }else if(1==RB6_source){
       if(RB6_InterruprHandler_LOW)
       {
        RB6_InterruprHandler_LOW();
       }
   }else{/*nothing*/}
   

}
/*External Interrupt RB7 MCAL Helper Function*/
void RB7_ISR(uint8 RB7_source){
    //this routine clears the interrupt flag  for the external interrupt, RBx
   EXT_RBx_InterruptFlagClear();
   if(0==RB7_source){
       if(RB7_InterruprHandler_HIGH)
       {
        RB7_InterruprHandler_HIGH();
       }
   }else if(1==RB7_source){
       if(RB7_InterruprHandler_LOW)
       {
        RB7_InterruprHandler_LOW();
       }
   }else{/*nothing*/}
   

}


/**
 * 
 * @param int_obj
 * @return 
 */
Std_ReturnType Interrupt_INTx_DeInit(const interrupt_INTx_t *int_obj){
    Std_ReturnType ret=E_OK;
    
    if(int_obj==NULL){
        ret=E_NOT_OK;        
    }
    else{
        ret=Interrupt_INTx_Disable(int_obj);
    }
    return ret;
}
/**
 * 
 * @param int_obj
 * @return 
 */
Std_ReturnType Interrupt_RBx_Init(const interrupt_RBx_t *int_obj){
    Std_ReturnType ret=E_OK;
    
    if(int_obj==NULL){
        ret=E_NOT_OK;        
    }
    else{
       /*Disable the External Interrupt*/
       EXT_RBx_InterruptDisable();
       /*Clear Interrupt Flag :External Interrupt did not occur*/
       EXT_RBx_InterruptFlagClear();
       /*configure priority*/
#if INTERRUPT_PRIORITY_LEVELS_ENABLE==INTERRUPT_FEATURE_ENABLE
        INTERRUPT_PriorityLevelEnable();
        if(INTERRUPT_LOW_PRIORITY==int_obj->priority){
            //this macro will enable low priority global interrupts
            INTERRUPT_GlobalInterruptLowEnable();
            //this routine set the RBx external interrupt priority to be Low priority, RBx
            EXT_RBx_LowPrioritySet();
        }
        else if(INTERRUPT_HIGH_PRIORITY==int_obj->priority){
            //this macro will enable high priority global interrupts
            INTERRUPT_GlobalInterruptHighEnable();
            //this routine set the RBx external interrupt priority to be High priority, RBx
            EXT_RBx_HighPrioritySet();
        }
        else{/*nothing*/}
#else
        INTERRUPT_GlobalInterruptEnable();
        INTERRUPT_PeripheralInteruuptEnable();
  #endif
        /*initialize RB pin to be input*/
        ret=gpio_pin_direction_intialize(&(int_obj->mcu_pin));
        /*Configure Default Interrupt CallBack*/
        switch(int_obj->mcu_pin.pin){
            case PIN4: 
                RB4_InterruprHandler_HIGH=int_obj->EXT_InterruptHandler_HIGH;
                RB4_InterruprHandler_LOW=int_obj->EXT_InterruptHandler_LOW;
                break;
            case PIN5: 
                RB5_InterruprHandler_HIGH=int_obj->EXT_InterruptHandler_HIGH;
                RB5_InterruprHandler_LOW=int_obj->EXT_InterruptHandler_LOW;
                break;
            case PIN6:
                RB6_InterruprHandler_HIGH=int_obj->EXT_InterruptHandler_HIGH;
                RB6_InterruprHandler_LOW=int_obj->EXT_InterruptHandler_LOW;
                break;
            case PIN7: 
                RB7_InterruprHandler_HIGH=int_obj->EXT_InterruptHandler_HIGH;
                RB7_InterruprHandler_LOW=int_obj->EXT_InterruptHandler_LOW;
                break;
            default:
                ret=E_NOT_OK;         
        }
        
        
       /*Enable the External Interrupt*/
       EXT_RBx_InterruptEnable();
       ret=E_OK;
    }
    return ret;
}
/**
 * 
 * @param int_obj
 * @return 
 */
Std_ReturnType Interrupt_RBx_DeInit(const interrupt_RBx_t *int_obj){
    Std_ReturnType ret=E_OK;
    
    if(int_obj==NULL){
        ret=E_NOT_OK;        
    }
    else{
        ret=EXT_RBx_InterruptDisable();
    }
    return ret;
}
/**
 * 
 * @param int_obj
 * @return 
 */
static Std_ReturnType Interrupt_INTx_Enable(const interrupt_INTx_t *int_obj){
    Std_ReturnType ret=E_OK;
    
    if(int_obj==NULL){
        ret=E_NOT_OK;        
    }
    else{
       switch(int_obj->source){
            case INTERRUPT_EXTERNAL_INT0:
#if INTERRUPT_PRIORITY_LEVELS_ENABLE==INTERRUPT_FEATURE_ENABLE
                INTERRUPT_GlobalInterruptHighEnable(); //INT0 always high priority 
#else
                INTERRUPT_GlobalInterruptEnable();
                INTERRUPT_PeripheralInteruuptEnable();
#endif
                EXT_INT0_INTERRUPTEnable();
                ret=E_OK; 
                break;
            case INTERRUPT_EXTERNAL_INT1:
#if INTERRUPT_PRIORITY_LEVELS_ENABLE==INTERRUPT_FEATURE_ENABLE
                INTERRUPT_PriorityLevelEnable();
                if(INTERRUPT_LOW_PRIORITY==int_obj->priority){
                    INTERRUPT_GlobalInterruptLowEnable();
                }
                else if(INTERRUPT_HIGH_PRIORITY==int_obj->priority){
                    INTERRUPT_GlobalInterruptHighEnable();
                }
                else{/*nothing*/}
#else
                INTERRUPT_GlobalInterruptEnable();
                INTERRUPT_PeripheralInteruuptEnable();
#endif
                EXT_INT1_INTERRUPTEnable();
                ret=E_OK;
                break;
            case INTERRUPT_EXTERNAL_INT2:
#if INTERRUPT_PRIORITY_LEVELS_ENABLE==INTERRUPT_FEATURE_ENABLE
                INTERRUPT_PriorityLevelEnable();
                if(INTERRUPT_LOW_PRIORITY==int_obj->priority){
                    INTERRUPT_GlobalInterruptLowEnable();
                }
                else if(INTERRUPT_HIGH_PRIORITY==int_obj->priority){
                    INTERRUPT_GlobalInterruptHighEnable();
                }
                else{/*nothing*/}
#else
                INTERRUPT_GlobalInterruptEnable();
                INTERRUPT_PeripheralInteruuptEnable();
#endif
                EXT_INT2_INTERRUPTEnable();
                ret=E_OK;
                break;
            default :ret=E_NOT_OK;
        }
    }
    return ret;
}
/**
 * 
 * @param int_obj
 * @return 
 */
static Std_ReturnType Interrupt_INTx_Disable(const  interrupt_INTx_t *int_obj){
    Std_ReturnType ret=E_OK;
    
    if(int_obj==NULL){
        ret=E_NOT_OK;        
    }
    else{
       switch(int_obj->source){
            case INTERRUPT_EXTERNAL_INT0:
                EXT_INT0_INTERRUPTDisable();
                ret=E_OK; 
                break;
            case INTERRUPT_EXTERNAL_INT1:
                EXT_INT1_INTERRUPTDisable();
                ret=E_OK;
                break;
            case INTERRUPT_EXTERNAL_INT2:
                EXT_INT2_INTERRUPTDisable();
                ret=E_OK;
                break;
            default :ret=E_NOT_OK;
        }
    }
    return ret;
}
/**
 * 
 * @param int_obj
 * @return 
 */
#if INTERRUPT_PRIORITY_LEVELS_ENABLE==INTERRUPT_FEATURE_ENABLE
static Std_ReturnType Interrupt_INTx_Priority_Init(const  interrupt_INTx_t *int_obj){
    Std_ReturnType ret=E_OK;
    
    if(int_obj==NULL){
        ret=E_NOT_OK;        
    }
    else{
       switch(int_obj->source){
            
            case INTERRUPT_EXTERNAL_INT1:
                if(INTERRUPT_LOW_PRIORITY==int_obj->priority){EXT_INT1_LowPrioritySet();}
                else if(INTERRUPT_HIGH_PRIORITY==int_obj->priority){EXT_INT1_HighPrioritySet();}
                else{/*nothing*/}
                ret=E_OK;
                break;
            case INTERRUPT_EXTERNAL_INT2:
                if(INTERRUPT_LOW_PRIORITY==int_obj->priority){EXT_INT2_LowPrioritySet();}
                else if(INTERRUPT_HIGH_PRIORITY==int_obj->priority){EXT_INT2_HighPrioritySet();}
                else{/*nothing*/}
                ret=E_OK;
                break;
            default :ret=E_NOT_OK;
        }
    }
    return ret;
}
#endif
/**
 * 
 * @param int_obj
 * @return 
 */
static Std_ReturnType Interrupt_INTx_Edge_Init(const  interrupt_INTx_t *int_obj){
    Std_ReturnType ret=E_OK;
    
    if(int_obj==NULL){
        ret=E_NOT_OK;        
    }
    else{
       switch(int_obj->source){
            case INTERRUPT_EXTERNAL_INT0:
                if(INTERRUPT_FALLING_EDGE==int_obj->edge){EXT_INT0_FallingEdgeSet();}
                else if(INTERRUPT_RISING_EDGE==int_obj->edge){EXT_INT0_RisingEdgeSet();}
                else{/*nothing*/}
                ret=E_OK; 
                break;
            case INTERRUPT_EXTERNAL_INT1:
                if(INTERRUPT_FALLING_EDGE==int_obj->edge){EXT_INT1_FallingEdgeSet();}
                else if(INTERRUPT_RISING_EDGE==int_obj->edge){EXT_INT1_RisingEdgeSet();}
                else{/*nothing*/}
                ret=E_OK;
                break;
            case INTERRUPT_EXTERNAL_INT2:
                if(INTERRUPT_FALLING_EDGE==int_obj->edge){EXT_INT2_FallingEdgeSet();}
                else if(INTERRUPT_RISING_EDGE==int_obj->edge){EXT_INT2_RisingEdgeSet();}
                else{/*nothing*/}
                ret=E_OK;
                break;
            default :ret=E_NOT_OK;
        }
    }
    return ret;
}
/**
 * 
 * @param int_obj
 * @return 
 */
static Std_ReturnType Interrupt_INTx_Pin_Init(const  interrupt_INTx_t *int_obj){
    Std_ReturnType ret=E_OK;
    
    if(int_obj==NULL){
        ret=E_NOT_OK;        
    }
    else{
        ret=gpio_pin_direction_intialize(&int_obj->mcu_pin);
    }
    return ret;
}

static Std_ReturnType Interrupt_INTx_Clear_Flag(const  interrupt_INTx_t *int_obj){
    Std_ReturnType ret=E_OK;
    
    if(int_obj==NULL){
        ret=E_NOT_OK;        
    }
    else{
        switch(int_obj->source){
            case INTERRUPT_EXTERNAL_INT0:
                EXT_INT0_INTERRUPTFlagClear();
                ret=E_OK; 
                break;
            case INTERRUPT_EXTERNAL_INT1:
                EXT_INT1_INTERRUPTFlagClear();
                ret=E_OK;
                break;
            case INTERRUPT_EXTERNAL_INT2:
                EXT_INT2_INTERRUPTFlagClear();
                ret=E_OK;
                break;
            default :ret=E_NOT_OK;
        }
    }
    return ret;
}

static Std_ReturnType INT0_set_InterruprHandler(void(* InterruprHandler)(void)){
    Std_ReturnType ret=E_OK;
    if(NULL==InterruprHandler){
        ret=E_NOT_OK; 
    }
    else{
        INT0_InterruprHandler=InterruprHandler;
    }
    return ret;
}
static Std_ReturnType INT1_set_InterruprHandler(void(* InterruprHandler)(void)){
    Std_ReturnType ret=E_OK;
    if(NULL==InterruprHandler){
        ret=E_NOT_OK; 
    }
    else{
        INT1_InterruprHandler=InterruprHandler;
    }
    return ret;
}
static Std_ReturnType INT2_set_InterruprHandler(void(* InterruprHandler)(void)){
    Std_ReturnType ret=E_OK;
    if(NULL==InterruprHandler){
        ret=E_NOT_OK; 
    }
    else{
        INT2_InterruprHandler=InterruprHandler;
    }
    return ret;
}
static Std_ReturnType Interrupt_INTx_set_InterruprHandler(const interrupt_INTx_t *int_obj){
    Std_ReturnType ret=E_OK;
    
    if(int_obj==NULL){
        ret=E_NOT_OK;        
    }
    else{
        switch(int_obj->source){
            case INTERRUPT_EXTERNAL_INT0:
                ret=INT0_set_InterruprHandler(int_obj->EXT_InterruptHandler); 
                break;
            case INTERRUPT_EXTERNAL_INT1:
                ret=INT1_set_InterruprHandler(int_obj->EXT_InterruptHandler);
                break;
            case INTERRUPT_EXTERNAL_INT2:
                ret=INT2_set_InterruprHandler(int_obj->EXT_InterruptHandler);
                break;
            default :ret=E_NOT_OK;
        }
    }
    return ret;
}