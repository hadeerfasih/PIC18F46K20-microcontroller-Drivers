/* 
 * File:   application.c
 * Author: Hadeer.Shrif
 *
 * Created on March 29, 2024, 12:15 AM
 */

#include "application.h"

led_t led2={
.port_name=PORTC_INDEX,
.pin=PIN1,
.led_status=LOW
};
led_t led3={
.port_name=PORTC_INDEX,
.pin=PIN2,
.led_status=LOW
};
led_t led4={
.port_name=PORTC_INDEX,
.pin=PIN3,
.led_status=LOW
};

void RB4_HIGH_Int_APP_ISR(void){
    led_turn_on(&led1);
    
}
void RB4_LOW_Int_APP_ISR(void){
    led_turn_on(&led2);
    
}
interrupt_RBx_t int_RB4={
.EXT_InterruptHandler_HIGH=RB4_HIGH_Int_APP_ISR,
.EXT_InterruptHandler_LOW=RB4_LOW_Int_APP_ISR,
.priority=INTERRUPT_HIGH_PRIORITY,
.mcu_pin.direction=INPUT,
.mcu_pin.port=PORTB_INDEX,
.mcu_pin.pin=PIN4
};

void RB5_HIGH_Int_APP_ISR(void){
    led_turn_off(&led1);
    
}
void RB5_LOW_Int_APP_ISR(void){
    led_turn_off(&led2);
    
}
interrupt_RBx_t int_RB5={
.EXT_InterruptHandler_HIGH=RB5_HIGH_Int_APP_ISR,
.EXT_InterruptHandler_LOW=RB5_LOW_Int_APP_ISR,
.priority=INTERRUPT_HIGH_PRIORITY,
.mcu_pin.direction=INPUT,
.mcu_pin.port=PORTB_INDEX,
.mcu_pin.pin=PIN5
};

void RB6_HIGH_Int_APP_ISR(void){
    led_turn_on(&led3);
    
}
void RB6_LOW_Int_APP_ISR(void){
    led_turn_on(&led4);
    
}
interrupt_RBx_t int_RB6={
.EXT_InterruptHandler_HIGH=RB6_HIGH_Int_APP_ISR,
.EXT_InterruptHandler_LOW=RB6_LOW_Int_APP_ISR,
.priority=INTERRUPT_HIGH_PRIORITY,
.mcu_pin.direction=INPUT,
.mcu_pin.port=PORTB_INDEX,
.mcu_pin.pin=PIN6
};

void RB7_HIGH_Int_APP_ISR(void){
    led_turn_off(&led3);
    
}
void RB7_LOW_Int_APP_ISR(void){
    led_turn_off(&led4);
    
}
interrupt_RBx_t int_RB7={
.EXT_InterruptHandler_HIGH=RB7_HIGH_Int_APP_ISR,
.EXT_InterruptHandler_LOW=RB7_LOW_Int_APP_ISR,
.priority=INTERRUPT_HIGH_PRIORITY,
.mcu_pin.direction=INPUT,
.mcu_pin.port=PORTB_INDEX,
.mcu_pin.pin=PIN7
};

Std_ReturnType ret=E_OK;

int main() {
    
    application_intialize();
    ret=Interrupt_RBx_Init(&int_RB4);
    ret=Interrupt_RBx_Init(&int_RB5);
    ret=Interrupt_RBx_Init(&int_RB6);
    ret=Interrupt_RBx_Init(&int_RB7);
    
    while(1){
//        if (PORTBbits.RB4 == 1) {
//            // Execute led_toggle function
//            led_toggle(&led1);
//        }
    }
        
       
    return (EXIT_SUCCESS);
}


void application_intialize(void){
    ecu_layer_initialize();
   ret=led_initialize(&led2);
   ret=led_initialize(&led3);
   ret=led_initialize(&led4);
}

