/* 
 * File:   ecu_seven_seg.c
 * Author: Hadeer Shrif
 *
 * Created on August 18, 2024, 12:58 AM
 */

#include "ecu_seven_seg.h"
/**
 * @brief
 * @param seg
 * @return status of the function
 *         [E_OK]:the function done successfully 
 *         [E_NOT_OK]:the function has issue to perform this action
 */
Std_ReturnType seven_segment_initialize(const segment_t *seg){
    Std_ReturnType ret=E_OK;
    
    if(seg==NULL){
        ret=E_NOT_OK;        
    }
    else{
        ret=gpio_pin_intialize(&(seg->segment_pins[SEGMENT_PIN0]));
        ret=gpio_pin_intialize(&(seg->segment_pins[SEGMENT_PIN1]));
        ret=gpio_pin_intialize(&(seg->segment_pins[SEGMENT_PIN2]));
        ret=gpio_pin_intialize(&(seg->segment_pins[SEGMENT_PIN3]));
    }
    return ret;


}
/**
 * @brief
 * @param seg
 * @param number
 * @return status of the function
 *         [E_OK]:the function done successfully 
 *         [E_NOT_OK]:the function has issue to perform this action
 */
Std_ReturnType seven_segment_write_number(const segment_t *seg,uint8 number){
    Std_ReturnType ret=E_OK;
    
    if((seg==NULL) &&(number>9)){
        ret=E_NOT_OK;        
    }
    else{
        ret=gpio_pin_write_logic(&(seg->segment_pins[SEGMENT_PIN0]),((number>>SEGMENT_PIN0)&0x01));
        ret=gpio_pin_write_logic(&(seg->segment_pins[SEGMENT_PIN1]),((number>>SEGMENT_PIN1)&0x01));
        ret=gpio_pin_write_logic(&(seg->segment_pins[SEGMENT_PIN2]),((number>>SEGMENT_PIN2)&0x01));
        ret=gpio_pin_write_logic(&(seg->segment_pins[SEGMENT_PIN3]),((number>>SEGMENT_PIN3)&0x01));
    }
    return ret;

}