/* 
 * File:   ecu_led_config.h
 * Author: pc
 *
 * Created on August 7, 2024, 11:15 PM
 */

#ifndef ECU_LED_CONFIG_H
#define	ECU_LED_CONFIG_H
/*section : includes*/
#include "../../MCAL_LAYER/GPIO/hal_gpio.h"
/*section : Macro declarations*/

/*section : Macro function declarations*/

/*section : Data type declarations*/

/*section : Function declarations*/

#endif	/* ECU_LED_CONFIG_H */

