/* 
 * File:   mcal_interrupt_config.h
 * Author: Hadeer Shrif
 *
 * Created on September 17, 2024, 4:03 PM
 */

#ifndef MCAL_INTERRUPT_CONFIG_H
#define	MCAL_INTERRUPT_CONFIG_H

/*--------------------------section : includes--------------------------------------*/
#include "../proc/pic18f4620.h"
#include "../mcal_std_types.h"
#include "mcal_interrupt_gen_cfg.h"
#include "../GPIO/hal_gpio.h"
/*section : Macro declarations*/
#define INTERUUPT_ENABLE             1
#define INTERRUPT_DISABLE            0
#define INTERRUPT_OCCUR              1
#define INTERRUPT_NOT_OCCUR          0
#define INTERRUPT_PRIORITY_ENABLE    1  
#define INTERRUPT_PRIORITY_DISABLE   0 
/*-------------------------section : Macro function declarations---------------------*/
#if INTERRUPT_PRIORITY_LEVELS_ENABLE==INTERRUPT_FEATURE_ENABLE

//this macro will enable priority levels on interrupts
#define INTERRUPT_PriorityLevelEnable()          (RCONbits.IPEN=1)
//this macro will disable priority levels on interrupts
#define INTERRUPT_PriorityLevelDisable()          (RCONbits.IPEN=0)

//this macro will enable high priority global interrupts
#define INTERRUPT_GlobalInterruptHighEnable()    (INTCONbits.GIEH=1)
//this macro will disable high priority global interrupts
#define INTERRUPT_GlobalInterruptHighDisable()   (INTCONbits.GIEH=0)

//this macro will enable low priority global interrupts
#define INTERRUPT_GlobalInterruptLowEnable()     (INTCONbits.GIEL=1)
//this macro will disable low priority global interrupts
#define INTERRUPT_GlobalInterruptLowDisable()    (INTCONbits.GIEL=0)
#else 
//this macro will enable global interrupts
#define INTERRUPT_GlobalInterruptEnable()    (INTCONbits.GIE=1)
//this macro will disable global interrupts
#define INTERRUPT_GlobalInterruptDisable()   (INTCONbits.GIE=0)
//this macro enable peripheral interrupts
#define INTERRUPT_PeripheralInteruuptEnable()    (INTCONbits.PEIE=1)
//this macro disable peripheral interrupts
#define INTERRUPT_PeripheralInteruuptDisable()   (INTCONbits.PEIE=0)
#endif

/*------------------------section : Data type declarations-------------------------*/

/*------------------------section : Function declarations--------------------------*/

#endif	/* MCAL_INTERRUPT_CONFIG_H */

