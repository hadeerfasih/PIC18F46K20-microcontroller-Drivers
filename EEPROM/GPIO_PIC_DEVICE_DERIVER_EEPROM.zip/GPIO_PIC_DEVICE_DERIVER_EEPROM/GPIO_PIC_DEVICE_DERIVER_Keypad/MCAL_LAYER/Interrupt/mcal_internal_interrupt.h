/* 
 * File:   mcal_internal_interrupt.h
 * Author: Hadeer Shrif
 *
 * Created on September 17, 2024, 4:05 PM
 */

#ifndef MCAL_INTERNAL_INTERRUPT_H
#define	MCAL_INTERNAL_INTERRUPT_H

/*section : includes*/
#include "mcal_interrupt_config.h"
/*section : Macro declarations*/

/*section : Macro function declarations*/

/*section : Data type declarations*/

/*section : Function declarations*/


#endif	/* MCAL_INTERNAL_INTERRUPT_H */

