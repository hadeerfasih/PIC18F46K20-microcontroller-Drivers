/* 
 * File:   eeprom.h
 * Author: Hadeer Shrif
 *
 * Created on September 20, 2024, 9:45 PM
 */

#ifndef EEPROM_H
#define	EEPROM_H

/*---------------section : Includes--------------------------------------*/
#include "../mcal_std_types.h"
#include "../proc/pic18f4620.h"
#include "../Interrupt/mcal_internal_interrupt.h"
/*---------------section : Macro declarations----------------------------*/
/*Flash program or Data EEPROM Memory Select*/
#define ACCESS_FLASH_PROGRAM_MEMORY        1
#define ACCESS_EEPOM_PROGRAM_MEMORY        0
/*Flash program/Data EEPROM or Configuration Select*/
#define ACCESS_CONFIG_REGISTERS            1
#define ACCESS_FLASH_EEPOM_MEMORY          0
/*Flash program/Data EEPROM Write Enable*/
#define ALLOW_WRITE_CYCLES_FLASH_EEPOM     1
#define INHIBITS_WRITE_CYCLES_FLASH_EEPOM  0
/*Write Control*/
#define INITIATE_DATA_EEPROM_WRITE_ERASE   1
#define DATA_EEPROM_WRITE_ERASE_COMPLETED  0
/*Read Control*/
#define INITIATE_DATA_EEPROM_READ          1
/*---------------section : Macro function declarations ------------------*/

/*---------------section : Data type declarations -----------------------*/

/*---------------section : Function declarations ------------------------*/
Std_ReturnType Data_EEPROM_WriteByte(uint16 bAdd, uint8 bData);
Std_ReturnType Data_EEPROM_ReadByte(uint16 bAdd, uint8 *bData);
#endif	/* EEPROM_H */

