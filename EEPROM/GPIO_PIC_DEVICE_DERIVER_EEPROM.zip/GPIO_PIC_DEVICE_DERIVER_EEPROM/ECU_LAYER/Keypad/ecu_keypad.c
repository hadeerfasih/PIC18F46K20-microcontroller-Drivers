/* 
 * File:   ecu_keypad.c
 * Author: Hadeer Shrif
 *
 * Created on August 28, 2024, 8:44 PM
 */
#include "ecu_keypad.h"
static const uint8 btn_values [ECU_KEYPAD_ROWS][ECU_KEYPAD_COLUMNS]={                                              
                                                        {'7','8','9','/'},
                                                        {'4','5','6','*'},
                                                        {'1','2','3','-'},
                                                        {'#','0','=','+'},
                                                                           };
/**
 * @brief
 * @param keypad_obj
 * @return status of the function
 *         [E_OK]:the function done successfully 
 *         [E_NOT_OK]:the function has issue to perform this action
 */
Std_ReturnType keypad_initialize(const keypad_t *keypad_obj){
    Std_ReturnType ret=E_OK;
    uint8 rows_counter=ZERO_INIT ,columns_counter=ZERO_INIT;
    if(keypad_obj==NULL){
        ret=E_NOT_OK;        
    }
    else{
        for(rows_counter=ZERO_INIT ; rows_counter<ECU_KEYPAD_ROWS ;rows_counter++ ){
            ret=gpio_pin_intialize(&(keypad_obj->keypad_row_pins[rows_counter]));//make pin outout and write logic zero
        }
        
        for(columns_counter=ZERO_INIT ; columns_counter< ECU_KEYPAD_COLUMNS ;columns_counter++ ){
            ret=gpio_pin_direction_intialize(&(keypad_obj->keypad_column_pins[columns_counter]));//make pin input
        }
    }
    return ret;


}

/**
 * @brief
 * @param keypad_obj
 * @param value
 * @return status of the function
 *         [E_OK]:the function done successfully 
 *         [E_NOT_OK]:the function has issue to perform this action
 */
Std_ReturnType keypad_get_value(const keypad_t *keypad_obj , uint8 *value){

    Std_ReturnType ret=E_OK;
    uint8 rows_counter=ZERO_INIT ,columns_counter=ZERO_INIT , counter=ZERO_INIT;
    uint8 column_logic=ZERO_INIT;
    if(keypad_obj==NULL || value==NULL){
        ret=E_NOT_OK;        
    }
    else{
      //for each row we will loop on the whole columns
        for(rows_counter=ZERO_INIT ; rows_counter<ECU_KEYPAD_ROWS ;rows_counter++ ){
            //at first turn off all keys
            for(counter=ZERO_INIT ; counter<ECU_KEYPAD_ROWS ;counter++ ){
                ret=gpio_pin_write_logic(&(keypad_obj->keypad_row_pins[counter]),LOW);
            }
            //then turn on the key you want
            ret=gpio_pin_write_logic(&(keypad_obj->keypad_row_pins[rows_counter]),HIGH);
            //scan all columns
            for(columns_counter=ZERO_INIT ; columns_counter< ECU_KEYPAD_COLUMNS ;columns_counter++ ){
                ret=gpio_pin_read_logic(&(keypad_obj->keypad_column_pins[columns_counter]),&column_logic);
                if(column_logic==HIGH){
                    *value=btn_values [rows_counter][columns_counter];
                }
             
            }
        }
    }
    return ret;

}