/* 
 * File:   ecu_keypad_config.h
 * Author: Hadeer Shrif
 *
 * Created on August 28, 2024, 8:44 PM
 */

#ifndef ECU_KEYPAD_CONFIG_H
#define	ECU_KEYPAD_CONFIG_H

/*section : includes*/
#include "../../MCAL_LAYER/GPIO/hal_gpio.h"
/*section : Macro declarations*/

/*section : Macro function declarations*/

/*section : Data type declarations*/

/*section : Function declarations*/


#endif	/* ECU_KEYPAD_CONFIG_H */

