/* 
 * File:   ecu_button_conf.h
 * Author: Hadeer Shrif
 *
 * Created on August 11, 2024, 11:09 PM
 */

#ifndef ECU_BUTTON_CONF_H
#define	ECU_BUTTON_CONF_H

/*section : includes*/
#include "../MCAL_LAYER/GPIO/hal_gpio.h"
/*section : Macro declarations*/

/*section : Macro function declarations*/

/*section : Data type declarations*/

/*section : Function declarations*/

#endif	/* ECU_BUTTON_CONF_H */

