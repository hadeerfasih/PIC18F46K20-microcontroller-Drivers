/* 
 * File:   ecu_relay_config.h
 * Author: Hadeer Shrif
 *
 * Created on August 13, 2024, 10:21 PM
 */

#ifndef ECU_RELAY_CONFIG_H
#define	ECU_RELAY_CONFIG_H



#endif	/* ECU_RELAY_CONFIG_H */

