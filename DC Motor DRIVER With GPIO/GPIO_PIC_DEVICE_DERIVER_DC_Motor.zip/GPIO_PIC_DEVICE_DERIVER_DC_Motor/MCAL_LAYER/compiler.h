/* 
 * File:   compiler.h
 * Author: pc
 *
 * Created on March 29, 2024, 5:26 PM
 */

#ifndef COMPILER_H
#define	COMPILER_H
////////section : Includes////////////////////////////////
#include <xc.h>

/////////section : Macro declarations ////////////////////

/////////section : Macro function declarations ///////////

/////////section : Data type declarations ///////////////

/////////section : Function declarations ///////////////
#endif	/* COMPILER_H */

