/* 
 * File:   application.c
 * Author: Hadeer.Shrif
 *
 * Created on March 29, 2024, 12:15 AM
 */



#include "application.h"

dc_motor_t dc_motor_1={
.dc_motor_pin[0].port=PORTC_INDEX,
.dc_motor_pin[0].pin=PIN0,
.dc_motor_pin[0].logic=DC_MOTOR_OFF_STATUS,
.dc_motor_pin[0].direction=OUTPUT,
.dc_motor_pin[1].port=PORTC_INDEX,
.dc_motor_pin[1].pin=PIN1,
.dc_motor_pin[1].logic=DC_MOTOR_OFF_STATUS,
.dc_motor_pin[1].direction=OUTPUT
};

dc_motor_t dc_motor_2={
.dc_motor_pin[0].port=PORTC_INDEX,
.dc_motor_pin[0].pin=PIN2,
.dc_motor_pin[0].logic=DC_MOTOR_OFF_STATUS,
.dc_motor_pin[0].direction=OUTPUT,
.dc_motor_pin[1].port=PORTC_INDEX,
.dc_motor_pin[1].pin=PIN3,
.dc_motor_pin[1].logic=DC_MOTOR_OFF_STATUS,
.dc_motor_pin[1].direction=OUTPUT
};


Std_ReturnType ret=E_OK;
int main() {

    application_intialize();
    while(1){
      ret=dc_motor_move_right(&dc_motor_1);
      ret=dc_motor_move_right(&dc_motor_2);
      __delay_ms(3000);
      ret=dc_motor_move_left(&dc_motor_1);
      ret=dc_motor_move_left(&dc_motor_2);
      __delay_ms(3000);
      ret=dc_motor_stop(&dc_motor_1);
      ret=dc_motor_stop(&dc_motor_2);
      __delay_ms(3000);
      ret=dc_motor_move_right(&dc_motor_1);
      ret=dc_motor_move_left(&dc_motor_2);
      __delay_ms(3000);
    }
    return (EXIT_SUCCESS);
}


void application_intialize(void){
    ret=dc_motor_initialize(&dc_motor_1);
    ret=dc_motor_initialize(&dc_motor_2);
//    ret=relay_initialize(&relay_1); 
//    ret=led_initialize(&led_1);  
}
