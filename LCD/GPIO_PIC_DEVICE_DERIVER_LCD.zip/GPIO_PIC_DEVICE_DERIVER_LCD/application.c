/* 
 * File:   application.c
 * Author: Hadeer.Shrif
 *
 * Created on March 29, 2024, 12:15 AM
 */

#include "application.h"


Std_ReturnType ret=E_OK;
uint8 lcd_counter=0;
uint8 lcd_counter_txt[4];

const uint8 HEART[] = {0x00,0x1B,0x15,0x11,0x0A,0x04,0x00,0x00};

const uint8 customChar_1[] = {0x0E,0x0A,0x11,0x11,0x11,0x11,0x1F,0x00};
const uint8 customChar_2[] = {0x0E,0x0A,0x11,0x11,0x11,0x1F,0x1F,0x00};
const uint8 customChar_3[] = {0x0E,0x0A,0x11,0x11,0x1F,0x1F,0x1F,0x00};
const uint8 customChar_4[] = {0x0E,0x0A,0x11,0x1F,0x1F,0x1F,0x1F,0x00};
const uint8 customChar_5[] = {0x0E,0x0A,0x1F,0x1F,0x1F,0x1F,0x1F,0x00};
int main() {
    application_intialize();
    //ret=lcd_8bit_send_string_pos(&lcd2,1,1,"counter: ");
    while(1){
//        ret=convert_byte_to_string(lcd_counter,lcd_counter_txt);
//        ret=lcd_8bit_send_string_pos(&lcd2,1,10,lcd_counter_txt);
//        lcd_counter++;
//        __delay_ms(100);
        ret=lcd_8bit_send_custom_char(&lcd2,1,10, HEART,0);
        ret=lcd_4bit_send_custom_char(&lcd1,1,10, HEART,0);
        ret=lcd_8bit_send_custom_char(&lcd2,1,20, customChar_1,1);
        __delay_ms(100);
        ret=lcd_8bit_send_custom_char(&lcd2,1,20, customChar_2,1);
        __delay_ms(100);
        ret=lcd_8bit_send_custom_char(&lcd2,1,20, customChar_3,1);
        __delay_ms(100);
        ret=lcd_8bit_send_custom_char(&lcd2,1,20, customChar_4,1);
        __delay_ms(100);
        ret=lcd_8bit_send_custom_char(&lcd2,1,20, customChar_5,1);
        __delay_ms(100);
    }
        
       
    return (EXIT_SUCCESS);
}


void application_intialize(void){
    ecu_layer_initialize();
   
}




//#include "application.h"
//
//
//Std_ReturnType ret=E_OK;
//uint8 lcd_counter=0;
//uint8 lcd_counter_txt[4];
//
//int main() {
//    application_intialize();
//    ret=lcd_8bit_send_string_pos(&lcd2,1,1,"counter: ");
//    while(1){
//        ret=convert_byte_to_string(lcd_counter,lcd_counter_txt);
//        ret=lcd_8bit_send_string_pos(&lcd2,1,10,lcd_counter_txt);
//        lcd_counter++;
//        __delay_ms(100);
//    }
//        
//       
//    return (EXIT_SUCCESS);
//}
//
//
//void application_intialize(void){
//    ecu_layer_initialize();
//   
//}





//#include "application.h"
//
//
//Std_ReturnType ret=E_OK;
//uint8 column_counter=ZERO_INIT;
//void welcome_message(void){
//    for(column_counter=1;column_counter<=5;column_counter++){
//        ret=lcd_4bit_send_string_pos(&lcd1,1,7,"Hello All");
//        ret=lcd_4bit_send_string_pos(&lcd1,2,5,"Embedded Dip");
//        __delay_ms(500);
//        ret=lcd_4bit_send_command(&lcd1,_LCD_CLEAR);
//        __delay_ms(100);
//    }
//}   
//void loading(void){
//    ret=lcd_8bit_send_string_pos(&lcd2,1,1,"loading");
//    for(column_counter=1;column_counter<=7;column_counter++){
//        ret=lcd_8bit_send_char_data_pos(&lcd2,1,7+column_counter,'.');  
//        __delay_ms(100);
//    }
//    ret=lcd_8bit_send_string_pos(&lcd2,1,8,"       ");
//}
//
//int main() {
//
//    application_intialize();
//    welcome_message();
//    while(1){
//        loading();
//    }
//        
//       
//    return (EXIT_SUCCESS);
//}
//
//
//void application_intialize(void){
//    ecu_layer_initialize();
//   
//}





//#include "application.h"
//
//
//Std_ReturnType ret=E_OK;
//uint8 column_counter=ZERO_INIT;
//int main() {
//
//    application_intialize();
//    ret=lcd_4bit_send_string_pos(&lcd1,2,3,"Embedded Dip");
//
//    while(1){
///**********************to shift one line from left to write******************88*/
//        
////        for(column_counter=5;column_counter<=7;column_counter++){
////            ret=lcd_4bit_send_string_pos(&lcd1,1,column_counter,"Hello All");
////           
////            __delay_ms(250);
////            ret=lcd_4bit_send_char_data_pos(&lcd1,1,column_counter,' ');//for shift from left to right clear from left
////        }
////        ret=lcd_4bit_send_string_pos(&lcd1,1,5,"            ");//space nums=word line+nums of shifts
//        
///**************************shift from right to left********************************************/
////        for(column_counter=7;column_counter>=5;column_counter--){
////            ret=lcd_4bit_send_string_pos(&lcd1,1,column_counter,"Hello All");
////           
////            __delay_ms(250);
////            ret=lcd_4bit_send_char_data_pos(&lcd1,1,column_counter+8,' ');//for shift from left to right clear from left
////        }
////        ret=lcd_4bit_send_string_pos(&lcd1,1,5,"            ");
////        
//    }
//        
//       
//    return (EXIT_SUCCESS);
//}
//
//
//void application_intialize(void){
//    ecu_layer_initialize();
//   
//}
//
//
