/* 
 * File:   application.h
 * Author: Hadeer.Shrif
 *
 * Created on March 29, 2024, 5:48 PM
 */

#ifndef APPLICATION_H
#define	APPLICATION_H
//////////section : Includes//////////////////////////
#include "ECU_LAYER/ecu_layer_init.h"
/////////section : Macro declarations ////////////////////
#define _XTAL_FREQ 8000000UL  // Define the clock frequency (e.g., 8 MHz)
/////////section : Macro function declarations ///////////

/////////section : Data type declarations ///////////////
extern keypad_t keypad1 ;
extern led_t led1;
extern chr_lcd_4bit_t lcd1; 
extern chr_lcd_8bit_t lcd2; 
/////////section : Function declarations ///////////////

void application_intialize(void);
#endif	/* APPLICATION_H */

