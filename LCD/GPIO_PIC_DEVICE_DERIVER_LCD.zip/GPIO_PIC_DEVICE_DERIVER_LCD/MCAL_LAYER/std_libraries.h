/* 
 * File:   std_libraries.h
 * Author: Hadeer.Shrif
 *
 * Created on March 29, 2024, 5:24 PM
 */

#ifndef STD_LIBRARIES_H
#define	STD_LIBRARIES_H
//////////section : Includes//////////////////////////////
#include <stdio.h>
#include <stdlib.h>

/////////section : Macro declarations ////////////////////

/////////section : Macro function declarations ///////////

/////////section : Data type declarations ///////////////

/////////section : Function declarations ///////////////

#endif	/* STD_LIBRARIES_H */

