/* 
 * File:   application.c
 * Author: Hadeer.Shrif
 *
 * Created on March 29, 2024, 12:15 AM
 */



#include "application.h"

relay_t relay_1={
.relay_port=PORTC_INDEX,
.relay_pin=PIN0,
.relay_status=RELAY_OFF_STATUS
};

led_t led_1={
.port_name=PORTC_INDEX,
.pin=PIN1,
.led_status=LOW
};


Std_ReturnType ret=E_OK;
int main() {

    application_intialize();
    while(1){
      ret=relay_turn_on(&relay_1); 
      ret=led_turn_off(&led_1);
      __delay_ms(2000);
      ret=relay_turn_off(&relay_1); 
      ret=led_turn_on(&led_1);
      __delay_ms(2000);
    }
    return (EXIT_SUCCESS);
}


void application_intialize(void){
    ret=relay_initialize(&relay_1); 
    ret=led_initialize(&led_1);  
}
