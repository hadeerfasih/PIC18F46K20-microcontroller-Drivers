/* 
 * File:   application.h
 * Author: Hadeer.Shrif
 *
 * Created on March 29, 2024, 5:48 PM
 */

#ifndef APPLICATION_H
#define	APPLICATION_H
//////////section : Includes//////////////////////////
#include "ECU_LAYER/LED/ecu_led.h"
#include "ECU_LAYER/ecu_button.h"
#include "ECU_LAYER/relay/ecu_relay.h"
/////////section : Macro declarations ////////////////////
#define _XTAL_FREQ 8000000UL  // Define the clock frequency (e.g., 8 MHz)
/////////section : Macro function declarations ///////////

/////////section : Data type declarations ///////////////

/////////section : Function declarations ///////////////

void application_intialize(void);
#endif	/* APPLICATION_H */

