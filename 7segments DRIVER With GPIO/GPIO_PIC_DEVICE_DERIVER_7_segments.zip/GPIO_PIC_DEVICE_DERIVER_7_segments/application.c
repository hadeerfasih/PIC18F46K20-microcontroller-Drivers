/* 
 * File:   application.c
 * Author: Hadeer.Shrif
 *
 * Created on March 29, 2024, 12:15 AM
 */



#include "application.h"
pin_config_t seg1_enable={
.direction=OUTPUT,
.pin=PIN0,
.port=PORTD_INDEX,
.logic=LOW
};
pin_config_t seg2_enable={
.direction=OUTPUT,
.pin=PIN1,
.port=PORTD_INDEX,
.logic=LOW
};

segment_t seg1={
.segment_pins[0].port=PORTC_INDEX,
.segment_pins[0].pin=PIN0,
.segment_pins[0].direction=OUTPUT,
.segment_pins[0].logic=LOW,

.segment_pins[1].port=PORTC_INDEX,
.segment_pins[1].pin=PIN1,
.segment_pins[1].direction=OUTPUT,
.segment_pins[1].logic=LOW,

.segment_pins[2].port=PORTC_INDEX,
.segment_pins[2].pin=PIN2,
.segment_pins[2].direction=OUTPUT,
.segment_pins[2].logic=LOW,

.segment_pins[3].port=PORTC_INDEX,
.segment_pins[3].pin=PIN3,
.segment_pins[3].direction=OUTPUT,
.segment_pins[3].logic=LOW,
.segment_type=SEGMENT_COMMON_ANODE
};

uint8 num=0,counter=0;
Std_ReturnType ret=E_OK;
int main() {

    application_intialize();
    while(1){
        for(counter=0;counter<=50;counter++){
        
        
            ret=seven_segment_write_number(&seg1,((uint8)num%10));
            ret=gpio_pin_write_logic(&seg1_enable,HIGH);
            __delay_ms(10);
            ret=gpio_pin_write_logic(&seg1_enable,LOW);
            
            ret=seven_segment_write_number(&seg1,((uint8)num/10));
            ret=gpio_pin_write_logic(&seg2_enable,HIGH);
            __delay_ms(10);
            ret=gpio_pin_write_logic(&seg2_enable,LOW);
        }
        num++;
        
    }
    return (EXIT_SUCCESS);
}


void application_intialize(void){
    ret=seven_segment_initialize(&seg1);
    ret=gpio_pin_intialize(&seg1_enable);
    ret=gpio_pin_intialize(&seg2_enable);
}
////////////////////count to 9 using seven segments DRIVER//////////////////////
/*
 #include "application.h"

segment_t seg1={
.segment_pins[0].port=PORTC_INDEX,
.segment_pins[0].pin=PIN0,
.segment_pins[0].direction=OUTPUT,
.segment_pins[0].logic=LOW,

.segment_pins[1].port=PORTC_INDEX,
.segment_pins[1].pin=PIN1,
.segment_pins[1].direction=OUTPUT,
.segment_pins[1].logic=LOW,

.segment_pins[2].port=PORTC_INDEX,
.segment_pins[2].pin=PIN2,
.segment_pins[2].direction=OUTPUT,
.segment_pins[2].logic=LOW,

.segment_pins[3].port=PORTC_INDEX,
.segment_pins[3].pin=PIN3,
.segment_pins[3].direction=OUTPUT,
.segment_pins[3].logic=LOW,
.segment_type=SEGMENT_COMMON_ANODE
};

uint8 num=0;
Std_ReturnType ret=E_OK;
int main() {

    application_intialize();
    while(1){
        for(num=0;num<10;num++){
            ret=seven_segment_write_number(&seg1,num);
            __delay_ms(500);
        }
        
        
    }
    return (EXIT_SUCCESS);
}


void application_intialize(void){
    ret=seven_segment_initialize(&seg1);
}
 
 
 */

//////////hour////////////////////////////////////
/*
 #include "application.h"

uint8 seconds=55 ,minuets=59 , hours=23;
uint8 counter=0;
Std_ReturnType ret=E_OK;
int main() {

    application_intialize();
    while(1){
        for(counter=0;counter<50;counter++){ //each line will be called 50 times in ne second
            ret=gpio_port_write_logic(PORTD_INDEX,0x3E);//connect the common of the first segment  0011 1110
            ret=gpio_port_write_logic(PORTC_INDEX,((uint8)(hours/10)));
            __delay_us(3333); //we need the total delay to be 20ms so 20/6=3333micro second 
            ret=gpio_port_write_logic(PORTD_INDEX,0x3D); //0011 1101
            ret=gpio_port_write_logic(PORTC_INDEX,((uint8)(hours%10)));
            __delay_us(3333);
            ret=gpio_port_write_logic(PORTD_INDEX,0x3B);//0011 1011
            ret=gpio_port_write_logic(PORTC_INDEX,((uint8)(minuets/10)));
            __delay_us(3333);
            ret=gpio_port_write_logic(PORTD_INDEX,0x37);//0011 0111
            ret=gpio_port_write_logic(PORTC_INDEX,((uint8)(minuets%10)));
            __delay_us(3333);
            ret=gpio_port_write_logic(PORTD_INDEX,0x2F);//0010 1111
            ret=gpio_port_write_logic(PORTC_INDEX,((uint8)(seconds/10)));
            __delay_us(3333);
            ret=gpio_port_write_logic(PORTD_INDEX,0x1F);//0001 1111
            ret=gpio_port_write_logic(PORTC_INDEX,((uint8)(seconds%10)));
            __delay_us(3333);
        }
        seconds++;
        if(seconds==60){
            minuets++;
            seconds=0;
        }
        if(minuets==60){
            hours++;
            minuets=0;
        }
        if(hours==24){
            hours=0;
        }
        
        
    }
    return (EXIT_SUCCESS);
}


void application_intialize(void){
    ret=gpio_port_direction_intialize(PORTC_INDEX,0xF0);
    ret=gpio_port_direction_intialize(PORTD_INDEX,0xC0);//all pins are output except the last two
}
 
 */
/////////////////////////////count from 0 to 99 on the same port////////////////////////
/*
 Std_ReturnType ret=E_OK;
uint8 i=0;
uint8 number_bcd=0;
int main() {

    application_intialize();
    while(1){
        if(i==99){
            i=0;
        }
        number_bcd=(((uint8)i%10)|(((uint8)i/10)<<4));
        
        gpio_port_write_logic(PORTC_INDEX,number_bcd); 
        i++;
        __delay_ms(200);
    }
    return (EXIT_SUCCESS);
}


void application_intialize(void){
    ret=gpio_port_direction_intialize(PORTC_INDEX,0x00);
    gpio_port_write_logic(PORTC_INDEX,0);
}

 */