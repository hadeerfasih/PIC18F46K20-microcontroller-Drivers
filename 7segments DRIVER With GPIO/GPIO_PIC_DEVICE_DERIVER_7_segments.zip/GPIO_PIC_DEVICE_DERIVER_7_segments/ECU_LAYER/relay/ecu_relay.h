/* 
 * File:   ecu_relay.h
 * Author: Hadeer Shrif
 *
 * Created on August 13, 2024, 10:20 PM
 */

#ifndef ECU_RELAY_H
#define	ECU_RELAY_H

/*section : includes*/
#include "../../MCAL_LAYER/GPIO/hal_gpio.h"
#include "ecu_relay_config.h"
/*section : Macro declarations*/
#define RELAY_ON_STATUS 0x01U
#define RELAY_OFF_STATUS 0x01U
/*section : Macro function declarations*/

/*section : Data type declarations*/
typedef struct{
    uint8 relay_port : 4;
    uint8 relay_pin : 3;
    uint8 relay_status : 1;
}relay_t;
/*section : Function declarations*/
Std_ReturnType relay_initialize(const relay_t *relay);
Std_ReturnType relay_turn_on(const relay_t *relay);
Std_ReturnType relay_turn_off(const relay_t *relay);
#endif	/* ECU_RELAY_H */

