/* 
 * File:   ecu_seven_seg_config.h
 * Author: Hadeer Shrif
 *
 * Created on August 18, 2024, 12:59 AM
 */

#ifndef ECU_SEVEN_SEG_CONFIG_H
#define	ECU_SEVEN_SEG_CONFIG_H

/*section : includes*/
#include "../../MCAL_LAYER/GPIO/hal_gpio.h"
/*section : Macro declarations*/

/*section : Macro function declarations*/

/*section : Data type declarations*/

/*section : Function declarations*/

#endif	/* ECU_SEVEN_SEG_CONFIG_H */

